CREATE VIEW AUTHOR_SALES
AS  SELECT N.fname, N.middle_inits, N.lname,
           sum(BO.quantity) as copies_sold, sum(BO.quantity * B.sales_price) as total_revenue
    FROM BOOK_ORDER BO, BOOK B, WRITTEN_BY WB, AUTHOR A, NAME N
    WHERE BO.isbn = B.isbn AND WB.isbn = B.isbn AND
          A.author_id = WB.author_id AND A.name_id = N.name_id
    GROUP BY A.author_id
    ORDER BY total_revenue DESC;

