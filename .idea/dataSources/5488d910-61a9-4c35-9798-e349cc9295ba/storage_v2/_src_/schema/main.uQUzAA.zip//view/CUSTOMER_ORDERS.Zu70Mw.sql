CREATE VIEW CUSTOMER_ORDERS
AS  SELECT order_id, sale_date, bill_no, sum(quantity) as total_books_purchased, sum(total_spent) as total_price
    FROM (SELECT O.order_id, O.sale_date, O.bill_no, B.sales_price,
        BO.quantity, BO.quantity * B.sales_price AS total_spent
        FROM "ORDER" O, BOOK_ORDER BO, BOOK B, USER U
        WHERE U.user_id = 50 AND U.user_id = O.customer_id AND
        O.order_id = BO.order_id AND B.isbn = BO.isbn)
    GROUP BY order_id
    ORDER BY sale_date DESC;

