CREATE VIEW WAREHOUSE_INVENTORY
AS  SELECT W.warehouse_id, WS.isbn, B.title,
           WS.quantity as inventory, WS.quantity * B.sales_price as inventory_value
    FROM WAREHOUSE W, WAREHOUSE_STOCK WS, BOOK B
    WHERE W.warehouse_id = WS.warehouse_id AND B.isbn = WS.isbn;

