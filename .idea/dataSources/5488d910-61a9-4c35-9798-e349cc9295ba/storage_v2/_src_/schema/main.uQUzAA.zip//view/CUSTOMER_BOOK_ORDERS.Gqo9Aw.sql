CREATE VIEW CUSTOMER_BOOK_ORDERS
AS  SELECT O.order_id, O.sale_date, BO.isbn, B.title, B.sales_price,
           BO.quantity, BO.quantity * B.sales_price AS total_spent
    FROM "ORDER" O, BOOK_ORDER BO, BOOK B, USER U
    WHERE U.user_id = 50 AND U.user_id = O.customer_id AND
    O.order_id = BO.order_id AND B.isbn = BO.isbn
    ORDER BY O.sale_date DESC;

